import { Component, OnInit } from '@angular/core';
import { EmployeeService, Employee } from '../employee.service';

@Component({
  selector: 'app-updateemp',
  templateUrl: './updateemp.component.html',
  styleUrls: ['./updateemp.component.css']
})
export class UpdateempComponent implements OnInit {
employee:EmployeeService;
  update(d:Employee){
    this.employee.updatedata(d);

  }
    
  
  constructor() { }

  ngOnInit() {
  }

}
