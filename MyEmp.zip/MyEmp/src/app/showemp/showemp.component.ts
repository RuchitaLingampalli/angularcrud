import { Component, OnInit } from '@angular/core';
import { EmployeeService, Employee} from '../employee.service';
@Component({
  selector: 'app-showemp',
  templateUrl: './showemp.component.html',
  styleUrls: ['./showemp.component.css']
})
export class ShowempComponent implements OnInit {
employee:EmployeeService;
dept :Employee[]=[];
updateboo:boolean=true;
  constructor(employee:EmployeeService) { 
    this.employee=employee;
  }
  delete(e){
    let index=this.dept.indexOf(e);
    this.dept.splice(index,1);
  }
  update(){
    this.updateboo=!this.updateboo;
  
  }
  updatedaw(d:Employee){
   this.employee.updatedata(d);
  }

  column:string="id"; 
  order:boolean=true;
  sort(column:string){
    //
    //if the click is for same column ,change the previous order
    // else order for ascending by default
    //  
    if(this.column==column )
    {
      this.order=!this.order;
    }else{
      this.order=true;
      this.column=column;
    }
  }

  ngOnInit() {
    this.employee.fetchData();
    this.dept=this.employee.getData();
  }

}
