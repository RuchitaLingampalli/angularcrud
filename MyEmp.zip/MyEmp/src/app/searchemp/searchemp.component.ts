import { Component, OnInit } from '@angular/core';
import { EmployeeService, Employee } from '../employee.service';

@Component({
  selector: 'app-searchemp',
  templateUrl: './searchemp.component.html',
  styleUrls: ['./searchemp.component.css']
})
export class SearchempComponent implements OnInit {
employ:EmployeeService;
ep:Employee[];
  constructor(employee:EmployeeService) { 
  this.employ=employee;
  }
  search(data){
    this.ep=this.employ.searchdata(data);
  }
  ngOnInit() {
  }

}
