import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowempComponent } from './showemp/showemp.component';
import {AddempComponent} from './addemp/addemp.component'
import { UpdateempComponent } from './updateemp/updateemp.component';
import { SearchempComponent} from './searchemp/searchemp.component'
const routes: Routes = [
  {
    path:"app-showemp",
    component:ShowempComponent
  },
  {
    path:"app-addemp",
    component:AddempComponent
  },
  {
    path:"app-updateemp",
    component:UpdateempComponent

  },
  {
    path:"app-searchemp",
    component:SearchempComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
